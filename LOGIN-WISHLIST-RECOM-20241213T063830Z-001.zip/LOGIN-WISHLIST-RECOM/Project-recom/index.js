// Import dependencies
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const { Firestore } = require('@google-cloud/firestore');

// Initialize Firestore and Express app
const firestore = new Firestore();
const app = express();
app.use(bodyParser.json());

// Define constants
const MODEL_PATH = './models/Recomended.json'; // Path ke file model
const PORT = 8080;
const COLLECTION_NAME = 'recom'; // Nama koleksi Firestore

// Load model from local file
function loadModel() {
    try {
        const modelData = fs.readFileSync(MODEL_PATH, 'utf-8');
        console.log('Model loaded successfully from', MODEL_PATH);
        return JSON.parse(modelData);
    } catch (error) {
        console.error('Error loading model:', error);
        throw error;
    }
}

// Match laptops based on price
function getRecommendations(model, targetPrice) {
    const threshold = 0.5; // 10% price deviation allowed
    return model.filtered_by_price.filter((item) => {
        const priceDifference = Math.abs(item.Price_in_IDR - targetPrice);
        return priceDifference / targetPrice <= threshold;
    }).map((item) => {
        // Exclude Laptop_Full_Description from the output
        const { Laptop_Full_Description, ...rest } = item;
        return rest;
    });
}

// Save recommendations to Firestore
async function saveRecommendationsToFirestore(recommendations) {
    try {
        const collectionRef = firestore.collection(COLLECTION_NAME);
        const docRef = await collectionRef.add({
            timestamp: new Date(),
            recommendations,
        });
        console.log('Recommendations saved to Firestore with ID:', docRef.id);
        return docRef.id;
    } catch (error) {
        console.error('Error saving recommendations to Firestore:', error);
        throw error;
    }
}

// API endpoint for recommendations
app.post('/recommend', async (req, res) => {
    const { price } = req.body;

    if (!price || typeof price !== 'number') {
        return res.status(400).json({ error: 'Invalid or missing price in request body.' });
    }

    try {
        // Load the model
        const model = loadModel();

        // Get recommendations
        const recommendations = getRecommendations(model, price);

        // Save recommendations to Firestore
        const firestoreId = await saveRecommendationsToFirestore(recommendations);

        // Respond with recommendations and Firestore document ID
        res.status(200).json({
            message: 'Recommendations generated and saved successfully.',
            firestoreId,
            recommendations,
        });
    } catch (error) {
        console.error('Error generating recommendations:', error);
        res.status(500).json({ error: 'Internal server error.' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
