const express = require("express");
const bodyParser = require("body-parser");
const admin = require("firebase-admin");

// Inisialisasi Firebase
const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();
const app = express();
app.use(bodyParser.json());

const collectionName = "sample_collection"; // Nama koleksi Firestore
const cartCollection = "carts";

// GET: List Nama Laptop
app.get("/api/laptops", async (req, res) => {
    try {
      const snapshot = await db.collection(collectionName).get();
      const laptops = snapshot.docs.map(doc => ({
        id: doc.id,
        name: doc.data().Laptop_Name,
      }));
      res.status(200).json(laptops);
    } catch (error) {
      res.status(500).json({ message: "Error fetching laptop names", error });
    }
  });
  
  // GET: Detail Laptop 
app.get("/api/items", async (req, res) => {
    try {
      const snapshot = await db.collection(collectionName).get();
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.status(200).json(items);
    } catch (error) {
      res.status(500).json({ message: "Error fetching data", error });
    }
  });
// POST: Tambah Laptop ke Keranjang
app.post("/api/cart", async (req, res) => {
  const { userId, laptopId, quantity } = req.body;

  try {
    // Cek apakah laptop sudah ada di keranjang
    const cartSnapshot = await db.collection(cartCollection)
      .where("userId", "==", userId)
      .where("laptopId", "==", laptopId)
      .get();

    if (cartSnapshot.empty) {
      // Tambah item baru ke keranjang
      await db.collection(cartCollection).add({
        userId,
        laptopId,
        quantity
      });
      res.status(201).json({ message: "Laptop added to cart" });
    } else {
      // Update quantity jika sudah ada di keranjang
      const cartItem = cartSnapshot.docs[0];
      const newQuantity = cartItem.data().quantity + quantity;
      await db.collection(cartCollection).doc(cartItem.id).update({ quantity: newQuantity });
      res.status(200).json({ message: "Laptop quantity updated in cart" });
    }
  } catch (error) {
    res.status(500).json({ message: "Error adding to cart", error });
  }
});

// GET: Lihat Keranjang Pengguna
app.get("/api/cart/:userId", async (req, res) => {
  const { userId } = req.params;

  try {
    const snapshot = await db.collection(cartCollection)
      .where("userId", "==", userId)
      .get();

    const cart = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));

    res.status(200).json(cart);
  } catch (error) {
    res.status(500).json({ message: "Error fetching cart", error });
  }
});

// DELETE: Hapus Laptop dari Keranjang
app.delete("/api/cart/:cartItemId", async (req, res) => {
  const { cartItemId } = req.params;

  try {
    await db.collection(cartCollection).doc(cartItemId).delete();
    res.status(200).json({ message: "Laptop removed from cart" });
  } catch (error) {
    res.status(500).json({ message: "Error removing from cart", error });
  }
});
  

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server is running on http://0.0.0.0:${PORT}`);
});
  
