package com.capstone.golap.data

data class UserModel(
    val email: String,
    val token: String?,
    val isLogin: Boolean
)