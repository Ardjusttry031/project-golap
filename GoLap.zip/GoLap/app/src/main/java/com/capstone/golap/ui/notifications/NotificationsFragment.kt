package com.capstone.golap.ui.notifications

class NotificationsFragment {
}